//
//  DayCollectionViewCell.h
//  BJTResearch
//
//  Created by gaoxin on 2018/1/3.
//  Copyright © 2018年 HZCitizenCard. All rights reserved.
//

#import <UIKit/UIKit.h>
@class DayModel;
@interface DayCollectionViewCell : UICollectionViewCell
@property(nonatomic,strong) DayModel *model;
@property(nonatomic,strong)NSString *stratTitle;
@property(nonatomic,strong)NSString *endTitle;
@end
