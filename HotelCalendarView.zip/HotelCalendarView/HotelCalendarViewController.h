//
//  HotelCalendarViewController.h
//  BJTResearch
//
//  Created by gaoxin on 2018/1/3.
//  Copyright © 2018年 HZCitizenCard. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HotelCalendarViewController : UIViewController
@property(nonatomic,copy) void(^selectCheckDateBlock)(NSString *startDate,NSString *endDate,NSString *days);
@property(nonatomic,copy) void(^hideBlock)(void);
@property(nonatomic,copy)NSString * startTimeStr;//开始时间 格式为(yyyy-MM-dd)
@property(nonatomic,copy)NSString * endTimeStr;//开始时间 格式为(yyyy-MM-dd)
@property(nonatomic,copy)NSString *stratTitle;
@property(nonatomic,copy)NSString *endTitle;
@end
