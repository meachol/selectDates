//
//  NSDate+Extension.h
//  ElectrocarShop
//
//  Created by hai on 2016/10/20.
//  Copyright © 2016年 hai. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (Extension)

/**
 获取传入时间的年份

 @param date 时间
 @return 年份
 */
+(NSInteger )getYearWithDate:(NSDate *)date;

/**
 获取传入时间的月份

 @param date 时间
 @return 月份
 */
+(NSInteger )getMonthWithDate:(NSDate *)date;

/**
 获取传入时间是星期几

 @param date 时间
 @return 星期几
 */
+(NSString *)getWeekDaysWithDate:(NSDate *)date;
/**
 获取传入时间是星期几
 
 @param date 时间
 @return 星期几
 */
+(NSString *)getWeekDaysWithDate2:(NSDate *)date;

/**
 获取传入时间是哪一天

 @param date 时间
 @return 哪一天
 */
+(NSInteger)getDaysWithDate:(NSDate *)date;

/**
 获取传入时间是这一年的第几周

 @param date 时间
 @return 第几周
 */
+(NSInteger)getWeekOfYearWithDate:(NSDate *)date;


/**
 获取传入时间是这个月的第几周

 @param date 时间
 @return 第几周
 */
+(NSInteger)getWeekOFMonthWithDate:(NSDate *)date;


/*!
 *  获取两个时间的时间差 --
 *
 *  @param frontDate 前一个时间
 *  @param toDate 后一个时间
 *
 *  @return     相差几年
 */
+ (NSInteger)yearIntervalFromDate:(NSDate *)frontDate  toDate:(NSDate *)toDate;
/*!
 *  获取两个时间的时间差 --
 *
 *  @param frontDate 前一个时间
 *  @param toDate 后一个时间
 *
 *  @return     相差几月
 */
+ (NSInteger)monthIntervalFromDate:(NSDate *)frontDate  toDate:(NSDate *)toDate;
/*!
 *  获取两个时间的时间差 --
 *
 *  @param frontDate 前一个时间
 *  @param toDate 后一个时间
 *
 *  @return     相差几天
 */
+ (NSInteger)dayIntervalFromDate:(NSDate *)frontDate  toDate:(NSDate *)toDate;

/*!
 *  获取两个时间的时间差 --
 *
 *  @param frontDate 前一个时间
 *  @param toDate 后一个时间
 *
 *  @return     相差几小时
 */
+ (NSInteger)hourIntervalFromDate:(NSDate *)frontDate  toDate:(NSDate *)toDate;
/*!
 *  获取两个时间的时间差 --
 *
 *  @param frontDate 前一个时间
 *  @param toDate 后一个时间
 *
 *  @return     相差几分
 */
+ (NSInteger)minuteIntervalFromDate:(NSDate *)frontDate  toDate:(NSDate *)toDate;
/*!
 *  获取两个时间的时间差 --
 *
 *  @param frontDate 前一个时间
 *  @param toDate 后一个时间
 *
 *  @return     相差几秒
 */
+ (NSInteger)secondIntervalFromDate:(NSDate *)frontDate  toDate:(NSDate *)toDate;



/*
 * 获取从开始时间起多久之后的时间
 *
 * @param beginDate：开始时间
 * @param year：年
 * @param month：月
 * @param day：日
 *
 * @return
 */
+ (NSDate *)dateFrom:(NSDate *)beginDate year:(NSInteger)year month:(NSInteger)month day:(NSInteger)day;

/*
 * 获取从开始时间起多久之后的时间
 *
 * @param beginDate：开始时间
 * @param hour：小时
 * @param minute：分
 *
 * @return
 */
+ (NSDate *)dateFrom:(NSDate *)beginDate hour:(NSInteger)hour minute:(NSInteger)minute;

/*!
 *  时间差
 *
 *  @param lastTime     前一个时间(字符串)
 *  @param format1      前一个时间格式
 *  @param currentTime  当前时间
 *  @param format2      当前时间格式
 *
 *  @return 刚刚  %ld分钟前  M月d日    。。。。。
 */
+ (NSString *)timeIntervalFromLastTime:(NSString *)lastTime
                        lastTimeFormat:(NSString *)format1
                         ToCurrentTime:(NSString *)currentTime
                     currentTimeFormat:(NSString *)format2;
/*!
 *  时间差
 *
 *  @param lastTime     前一个时间
 *  @param currentTime  当前时间
 *
 *  @return 刚刚  %ld分钟前  M月d日    。。。。。
 */
+ (NSString *)timeIntervalFromLastTime:(NSDate *)lastTime ToCurrentTime:(NSDate *)currentTime;

@end
