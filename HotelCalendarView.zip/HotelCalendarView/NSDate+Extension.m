//
//  NSDate+Extension.m
//  ElectrocarShop
//
//  Created by hai on 2016/10/20.
//  Copyright © 2016年 hai. All rights reserved.
//

#import "NSDate+Extension.h"

@implementation NSDate (Extension)
//获取NSDateComponents
+(NSDateComponents *)getComponentsWithDate:(NSDate *)date{
    //获取日期
    NSCalendar *calendar = [[NSCalendar alloc]initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    //设置时区
    calendar.locale = [[NSLocale alloc] initWithLocaleIdentifier:@"ZH_cn"];
    NSDateComponents *comps = [[NSDateComponents alloc] init];
    NSInteger unitFlags = NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay|NSCalendarUnitWeekday|NSCalendarUnitHour|NSCalendarUnitMinute|NSCalendarUnitSecond|NSCalendarUnitWeekOfMonth;
    
    comps = [calendar components:unitFlags fromDate:date];
    return comps;
}
+(NSInteger)getYearWithDate:(NSDate *)date{
    return [[NSDate getComponentsWithDate:date] year];
}
+(NSInteger)getMonthWithDate:(NSDate *)date{
    return [[NSDate getComponentsWithDate:date] month];
}
+(NSInteger)getDaysWithDate:(NSDate *)date{
    return [[NSDate getComponentsWithDate:date] day];
}
+(NSString *)getWeekDaysWithDate:(NSDate *)date{
    NSArray * arrWeek=[NSArray arrayWithObjects:@"星期日",@"星期一",@"星期二",@"星期三",@"星期四",@"星期五",@"星期六",nil];
    return [arrWeek objectAtIndex:([[NSDate getComponentsWithDate:date] weekday]-1)];
}
+(NSString *)getWeekDaysWithDate2:(NSDate *)date{
    NSArray * arrWeek=[NSArray arrayWithObjects:@"周日",@"周一",@"周二",@"周三",@"周四",@"周五",@"周六",nil];
    return [arrWeek objectAtIndex:([[NSDate getComponentsWithDate:date] weekday]-1)];
}
+(NSInteger)getWeekOfYearWithDate:(NSDate *)date{
    return  [[NSDate getComponentsWithDate:date] weekOfYear];
}
+(NSInteger)getWeekOFMonthWithDate:(NSDate *)date{
    return [[NSDate getComponentsWithDate:date] weekOfMonth];
}
/*!
 *  获取两个时间的时间差 --
 *
 *  @param frontDate 前一个时间
 *  @param toDate 后一个时间
 *
 *  @return     相差几年
 */
+ (NSInteger)yearIntervalFromDate:(NSDate *)frontDate  toDate:(NSDate *)toDate
{
    return [self timeIntervalFromLastDate:frontDate toTheDate:toDate calendarUnit:NSCalendarUnitYear].year;
}
/*!
 *  获取两个时间的时间差 --
 *
 *  @param frontDate 前一个时间
 *  @param toDate 后一个时间
 *
 *  @return     相差几月
 */
+ (NSInteger)monthIntervalFromDate:(NSDate *)frontDate  toDate:(NSDate *)toDate
{
    return [self timeIntervalFromLastDate:frontDate toTheDate:toDate calendarUnit:NSCalendarUnitMonth].month;
}
/*!
 *  获取两个时间的时间差 --
 *
 *  @param frontDate 前一个时间
 *  @param toDate 后一个时间
 *
 *  @return     相差几天
 */
+ (NSInteger)dayIntervalFromDate:(NSDate *)frontDate  toDate:(NSDate *)toDate
{
    return [self timeIntervalFromLastDate:frontDate toTheDate:toDate calendarUnit:NSCalendarUnitDay].day;
}

/*!
 *  获取两个时间的时间差 --
 *
 *  @param frontDate 前一个时间
 *  @param toDate 后一个时间
 *
 *  @return     相差几小时
 */
+ (NSInteger)hourIntervalFromDate:(NSDate *)frontDate  toDate:(NSDate *)toDate
{
    return [self timeIntervalFromLastDate:frontDate toTheDate:toDate calendarUnit:NSCalendarUnitHour].hour;
}
/*!
 *  获取两个时间的时间差 --
 *
 *  @param frontDate 前一个时间
 *  @param toDate 后一个时间
 *
 *  @return     相差几分
 */
+ (NSInteger)minuteIntervalFromDate:(NSDate *)frontDate  toDate:(NSDate *)toDate
{
    return [self timeIntervalFromLastDate:frontDate toTheDate:toDate calendarUnit:NSCalendarUnitMinute].minute;
}
/*!
 *  获取两个时间的时间差 --
 *
 *  @param frontDate 前一个时间
 *  @param toDate 后一个时间
 *
 *  @return     相差几秒
 */
+ (NSInteger)secondIntervalFromDate:(NSDate *)frontDate  toDate:(NSDate *)toDate
{
    return [self timeIntervalFromLastDate:frontDate toTheDate:toDate calendarUnit:NSCalendarUnitSecond].second;
}

+ (NSDateComponents *)timeIntervalFromLastDate:(NSDate *)frontDate  toTheDate:(NSDate *)nowDate calendarUnit:(NSCalendarUnit)unit
{
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDateComponents *dateComponents = [calendar components:unit fromDate:frontDate toDate:nowDate options:0];
    
    return dateComponents;
}



/*
 * 获取从开始时间起多久之后的时间
 *
 * @param beginDate：开始时间
 * @param year：年
 * @param month：月
 * @param day：日
 *
 * @return
 */
+ (NSDate *)dateFrom:(NSDate *)beginDate year:(NSInteger)year month:(NSInteger)month day:(NSInteger)day
{
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
//    NSDateComponents *comps = nil;
//    comps = [calendar components:NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay fromDate:beginDate];
    NSDateComponents *adcomps = [[NSDateComponents alloc] init];
    
    [adcomps setYear:year];
    [adcomps setMonth:month];
    [adcomps setDay:day];
    [adcomps setMinute:2];
    
    NSDate *newdate = [calendar dateByAddingComponents:adcomps toDate:beginDate options:0];
    
    return newdate;
}
/*
 * 获取从开始时间起多久之后的时间
 *
 * @param beginDate：开始时间
 * @param hour：小时
 * @param minute：分
 *
 * @return
 */
+ (NSDate *)dateFrom:(NSDate *)beginDate hour:(NSInteger)hour minute:(NSInteger)minute
{
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
//    NSDateComponents *comps = nil;
//    comps = [calendar components:NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay fromDate:beginDate];
    NSDateComponents *adcomps = [[NSDateComponents alloc] init];
    
    [adcomps setHour:hour];
    [adcomps setMinute:minute];
    
    NSDate *newdate = [calendar dateByAddingComponents:adcomps toDate:beginDate options:0];
    
    return newdate;
}


+ (NSString *)timeIntervalFromLastTime:(NSString *)lastTime
                        lastTimeFormat:(NSString *)format1
                         ToCurrentTime:(NSString *)currentTime
                     currentTimeFormat:(NSString *)format2
{
    //上次时间
    NSDateFormatter *dateFormatter1 = [[NSDateFormatter alloc]init];
    dateFormatter1.dateFormat = format1;
    NSDate *lastDate = [dateFormatter1 dateFromString:lastTime];
    //当前时间
    NSDateFormatter *dateFormatter2 = [[NSDateFormatter alloc]init];
    dateFormatter2.dateFormat = format2;
    NSDate *currentDate = [dateFormatter2 dateFromString:currentTime];
    return [NSDate timeIntervalFromLastTime:lastDate ToCurrentTime:currentDate];
}

+ (NSString *)timeIntervalFromLastTime:(NSDate *)lastTime ToCurrentTime:(NSDate *)currentTime
{
    NSTimeZone *timeZone = [NSTimeZone systemTimeZone];
    //上次时间
    NSDate *lastDate = [lastTime dateByAddingTimeInterval:[timeZone secondsFromGMTForDate:lastTime]];
    //当前时间
    NSDate *currentDate = [currentTime dateByAddingTimeInterval:[timeZone secondsFromGMTForDate:currentTime]];
    //时间间隔
    NSInteger intevalTime = [currentDate timeIntervalSinceReferenceDate] - [lastDate timeIntervalSinceReferenceDate];
    
    //秒、分、小时、天、月、年
    NSInteger minutes = intevalTime / 60;
    NSInteger hours = intevalTime / 60 / 60;
    NSInteger day = intevalTime / 60 / 60 / 24;
    NSInteger month = intevalTime / 60 / 60 / 24 / 30;
    NSInteger yers = intevalTime / 60 / 60 / 24 / 365;
    //单位为分钟
    if (minutes <= 10) {
        return  @"刚刚";
    }else if (minutes < 60){
        return [NSString stringWithFormat: @"%ld分钟前",(long)minutes];
    }else if (hours < 24){
        return [NSString stringWithFormat: @"%ld小时前",(long)hours];
    }else if (day < 30){
        return [NSString stringWithFormat: @"%ld天前",(long)day];
    }else if (month < 12){
        NSDateFormatter * df =[[NSDateFormatter alloc]init];
        df.dateFormat = @"M月d日";
        NSString * time = [df stringFromDate:lastDate];
        return time;
    }else if (yers >= 1){
        NSDateFormatter * df =[[NSDateFormatter alloc]init];
        df.dateFormat = @"yyyy年M月d日";
        NSString * time = [df stringFromDate:lastDate];
        return time;
    }
    return @"";
}

@end
