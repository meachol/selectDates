
//
//  MonthTableViewCell.m
//  BJTResearch
//
//  Created by gaoxin on 2018/1/3.
//  Copyright © 2018年 HZCitizenCard. All rights reserved.
//

#import "MonthTableViewCell.h"
#import "MonthModel.h"
#import "DayCollectionViewCell.h"

#define UIColorFromRGBA(RGBValue, alphaValue) [UIColor colorWithRed:((float)((RGBValue & 0xFF0000) >> 16))/255.0 green:((float)((RGBValue & 0x00FF00) >> 8))/255.0 blue:((float)(RGBValue & 0x0000FF))/255.0 alpha:alphaValue]

@interface MonthTableViewCell ()<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>
@property(nonatomic,strong)UICollectionView *collectionView;
@property(nonatomic,strong)UILabel *dateLabel;
@end
@implementation MonthTableViewCell
//+ (instancetype)cellWithTableView:(UITableView *)tableView{
//
//    static NSString *CellID = @"MonthTableViewCellID";
//    MonthTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellID];
//    if (cell==nil) {
//        cell = [[MonthTableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellID];
//
//    }
//    cell.userInteractionEnabled = YES;
//    return cell;
//}
//
//- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
//    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
//    if (self) {
//        self.selectionStyle = UITableViewCellSelectionStyleNone;
//        [self setContentView];
//    }
//    return self;
//}

- (void)setContentView{
//    UIView *lineView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 9)];
//    lineView.backgroundColor = [UIColor clearColor];
//    [self.contentView addSubview:lineView];
    [self.contentView addSubview:self.collectionView];
}
-(UILabel *)dateLabel
{
    if (!_dateLabel) {
        _dateLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 10, [UIScreen mainScreen].bounds.size.width, 48  )];
        _dateLabel.textAlignment = NSTextAlignmentCenter;
        _dateLabel.font = [UIFont systemFontOfSize:14];
        _dateLabel.textColor = UIColorFromRGBA(0x333333, 1.0);
        [self.contentView addSubview:_dateLabel];
    }
    return _dateLabel;
}
-(UICollectionView *)collectionView
{
    if (!_collectionView) {
        UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc]init];
        flowLayout.minimumLineSpacing = 4;
        flowLayout.minimumInteritemSpacing = 0;
        flowLayout.sectionInset = UIEdgeInsetsMake(0, 0, 0, 0);
        flowLayout.itemSize =  CGSizeMake(([UIScreen mainScreen].bounds.size.width-44)/7, ([UIScreen mainScreen].bounds.size.width-44)/7);
        
        _collectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(20, 60, [UIScreen mainScreen].bounds.size.width-44, 370) collectionViewLayout:flowLayout];
        
        _collectionView.dataSource = self;
        _collectionView.delegate = self;
        _collectionView.bounces = NO;
        _collectionView.scrollEnabled = NO;
        _collectionView.backgroundColor = [UIColor clearColor];
//        [_collectionView registerClass:[DayCollectionViewCell class] forCellWithReuseIdentifier:@"DayCollectionViewCellID"];
        //分别注册 多个不同重用标示的Cell
              for (NSInteger i = 0; i < 60 ; i++) {
                  NSString * stringID = [NSString stringWithFormat:@"DayCollectionViewCellId%ld",i];
                  ///@"DayCollectionViewCellID"
                  [_collectionView registerClass:[DayCollectionViewCell class] forCellWithReuseIdentifier:stringID];
              }
    }
    return _collectionView;
}



#pragma mark - 设置内容
- (void)setModel:(MonthModel *)model{
    _model = model;
    
    dispatch_async(dispatch_get_main_queue(), ^{
        CGRect frame = self.collectionView.frame;
        frame.size.height = model.cellHight - 60;
        self.collectionView.frame = frame;
    });
    self.dateLabel.text = [NSString stringWithFormat:@"%04ld年%02ld月",model.year ,model.month];
//    self.selectionStyle = UITableViewCellSelectionStyleNone;
    self.dateLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:14];
    self.dateLabel.textColor = [UIColor colorWithRed:51/255.0 green:51/255.0 blue:51/255.0 alpha:1/1.0];
    [self.collectionView reloadData];
}


-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return _model.cellNum+1;
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    NSString * stringID = [NSString stringWithFormat:@"DayCollectionViewCellId%ld",indexPath.row];
       DayCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:stringID forIndexPath:indexPath];
//    DayCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"DayCollectionViewCellID" forIndexPath:indexPath];
    NSLog(@"%ld,%ld",_model.days.count , _model.cellStartNum);
    cell.stratTitle=self.stratTitle;
    cell.endTitle=self.endTitle;
    if ((indexPath.row < _model.cellStartNum) || (indexPath.row >= (_model.days.count + _model.cellStartNum))) {
        cell.model = nil;
    }else{
        DayModel *model = _model.days[indexPath.row - _model.cellStartNum];
        cell.model = model;
    }
    return cell;
}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    if ((indexPath.row < _model.cellStartNum) || (indexPath.row >= (_model.days.count + _model.cellStartNum))) {
        return;
    }else{
        DayModel *model = _model.days[indexPath.row - _model.cellStartNum];
        if (self.selectedDay) {
            self.selectedDay(model);
        }
    }
    
}

@end
