//
//  MonthModel.m
//  BJTResearch
//
//  Created by gaoxin on 2018/1/3.
//  Copyright © 2018年 HZCitizenCard. All rights reserved.
//

#import "MonthModel.h"


@implementation DayModel

@end
@implementation MonthModel

@end
